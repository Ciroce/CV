// console.log("funciona controlCV")
arrayEstudiosyconocimientos_ = [
    "Direccion de cine",
    "Guion de cine",
    "Diseñador multimedial",
    "Direccion de fotografia",
    "Redaccion publicitaria",
    "Escritor compositor",
    "Musico",
    "Guitarrista",
    "Cantante"
]
let estudiosLista = document.getElementById("estudios");
console.log(estudiosLista);
for (let valor of arrayEstudiosyconocimientos_){
    estudiosLista.insertAdjacentHTML("afterbegin", '<li>' + valor + '</li>');
}